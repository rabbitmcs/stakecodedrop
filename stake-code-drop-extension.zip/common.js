// Shared config + helpers. Loaded by background.js (importScripts) and by the
// options/popup pages (<script src>). Must stay plain script, no modules.

const DB = 'https://eddies-codes-default-rtdb.firebaseio.com';

// Two Stake feeds, now watched independently - you can have Stake.com and
// Stake.us both active at once, each catching its own codes.
const SITES = [
  { id: 'com', label: 'Stake.com', node: 'stakecom' },
  { id: 'us', label: 'Stake.us', node: 'stakeus' }
];

const siteById = (id) => SITES.find((s) => s.id === id) || SITES[0];
const streamUrl = (node) => `${DB}/byCasino/${node}.json`;

const DEFAULT_THRILL_CURRENCY = 'USDT';

const DEFAULTS = {
  // Stake.com / Stake.us / Thrill can each be enabled independently.
  stakeComEnabled: true,
  stakeUsEnabled: false,
  thrillEnabled: true,

  // Per-site redeem config.
  comDomain: 'stake.com',
  comCurrency: 'ltc',
  usDomain: 'stake.us',
  usCurrency: 'sweeps',

  // Which Stake buckets to act on (shared across both Stake sites).
  catchDaily: true,
  catchHighRoller: true,
  catchOther: false,

  // Stake bucket rules, matched against the drop's dollar value.
  dailyAmounts: '1, 3, 5',
  highRollerAmounts: '12.50, 12, 25, 50',

  // Ignore anything that landed more than this many seconds ago, so a
  // reconnect can never dump a pile of dead codes into your tabs.
  maxAgeSeconds: 900,

  openInBackground: false,
  notify: true,

  // VIP reload auto-claim, per Stake site.
  comReload: false,
  usReload: false,
  reloadNotify: true,

  // Stake.us free daily bonus (the 'daily dollar').
  usDaily: false,
  dailyNotify: true,

  // Rainbet bonus-drop auto-claimer.
  rainbetEnabled: true,
  rainbetBonus: true,   // Rainbet Bonus channel
  rainbetVip: true,     // Rainbet VIP Bonus channel
  rainbetNotify: true,
  rainbetReload: false,  // daily reload, 3x a day
  rainbetDaily: false,   // daily bonus chest
  rbTimedNotify: true,

  // Thrill cash-drop auto-claimer config.
  thrillCurrency: DEFAULT_THRILL_CURRENCY,
  thrillNotify: true
};

// Common Stake.com mirrors. The list rotates constantly, so the options page
// also accepts anything you type.
const KNOWN_DOMAINS = {
  com: [
    'stake.com', 'stake.jp', 'stake.bet', 'stake.ceo', 'stake.games', 'stake.mba',
    'stake.krd', 'stake.bz', 'stake.ac', 'stake.pet', 'staketr.com', 'stakeru8.com',
    'stakeru9.com', 'stkmirror.com', 'stake1017.com', 'stake1020.com', 'stake1021.com', 'stake1022.com',
    'stake1034.com', 'stake1035.com', 'stake1036.com', 'stake1037.com', 'stake1038.com', 'stake1039.com',
    'stake1043.com', 'stake1048.com', 'stake1052.com', 'stake1057.com', 'stake1061.com', 'stake1066.com',
    'stake1067.com', 'stake1068.com', 'stake1069.com', 'stake1070.com', 'stake1071.com', 'stake1072.com',
    'stake1073.com', 'stake1074.com', 'stake1075.com', 'stake1076.com', 'stake1077.com', 'stake1078.com',
    'stake1079.com', 'stake1080.com', 'stake1081.com', 'stake1082.com', 'stake1083.com', 'stake1084.com',
    'stake1085.com', 'stake1086.com', 'stake1087.com', 'stake1088.com', 'stake1089.com', 'stake1090.com',
    'stake1091.com', 'stake1092.com', 'stake1093.com', 'stake1094.com', 'stake1095.com', 'stake3000.com',
    'stake3001.com', 'stake3002.com', 'stake3003.com', 'stake3004.com', 'stake3005.com', 'stake3006.com',
    'stake3007.com', 'stake3008.com', 'stake3009.com', 'stake3010.com', 'stake3011.com', 'stake3012.com',
    'stake3013.com', 'stake3014.com', 'stake3015.com', 'stake3016.com', 'stake3017.com', 'stake3018.com',
    'stake3019.com', 'stake3020.com', 'stake3026.com', 'stake3027.com', 'stake3028.com', 'stake3029.com',
    'stake3030.com', 'stake3033.com', 'stake3035.com', 'stake3039.com', 'stake3040.com', 'stake3041.com',
    'stake3043.com', 'stake3045.com', 'stake3046.com', 'stake3047.com', 'stake3048.com', 'stake3050.com',
    'stake3051.com', 'stake3053.com', 'stake3056.com', 'stake3058.com', 'stake3061.com', 'stake3062.com',
    'stake3064.com', 'stake3065.com', 'stake3067.com', 'stake3069.com', 'stake3070.com', 'stake3072.com',
    'stake3075.com', 'stake3077.com', 'stake3079.com', 'stake3080.com', 'stake3082.com', 'stake3083.com',
    'stake3084.com', 'stake3085.com', 'stake3086.com', 'stake3087.com', 'stake3088.com', 'stake3090.com',
    'stake3094.com', 'stake3098.com', 'stake3099.com', 'stake3103.com', 'stake3104.com', 'stake3107.com',
    'stake3109.com', 'stake3112.com', 'stake3114.com', 'stake3116.com', 'stake3119.com', 'stake3199.com'
  ],
  us: ['stake.us']
};

const CURRENCIES = {
  com: ['ltc', 'btc', 'eth', 'usdt', 'usdc', 'sol', 'doge', 'trx', 'xrp',
        'bch', 'bnb', 'link', 'ada', 'dai', 'pol', 'shib', 'ape', 'eos'],
  us: ['sweeps', 'gold']
};

// Currencies Thrill's cash-drop redeem endpoint understands.
const THRILL_CURRENCIES = ['USDT', 'USDC', 'BTC', 'ETH', 'SOL'];

function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULTS, (s) => resolve({
      ...s,
      dailyAmounts: DEFAULTS.dailyAmounts,
      highRollerAmounts: DEFAULTS.highRollerAmounts,
      maxAgeSeconds: DEFAULTS.maxAgeSeconds,
      openInBackground: false,
      usCurrency: 'sweeps'   // Stake.us bonuses are always Sweeps
    }));
  });
}

// Redeem config for a specific site id ('com' or 'us').
function siteConfig(id, settings) {
  const s = siteById(id);
  return {
    id: s.id,
    label: s.label,
    node: s.node,
    domain: settings[`${s.id}Domain`],
    currency: settings[`${s.id}Currency`]
  };
}

// Whether a given Stake site is enabled in settings.
function siteEnabled(id, settings) {
  return id === 'us' ? settings.stakeUsEnabled : settings.stakeComEnabled;
}

// "1, 3, 5" -> [1, 3, 5]. Bad entries are dropped rather than throwing.
function parseAmounts(text) {
  return String(text || '')
    .split(',')
    .map((p) => parseFloat(p.trim()))
    .filter((n) => !Number.isNaN(n));
}

/*
 * Firebase has no type field, so the bucket is derived from the dollar value.
 * A drop with no value at all can't be classified and falls to "other".
 */
function classify(record, settings) {
  const amount = parseFloat(record.amount);
  if (Number.isNaN(amount)) return 'other';
  if (parseAmounts(settings.dailyAmounts).includes(amount)) return 'daily';
  if (parseAmounts(settings.highRollerAmounts).includes(amount)) return 'highroller';
  return 'other';
}

function wanted(bucket, settings) {
  if (bucket === 'daily') return settings.catchDaily;
  if (bucket === 'highroller') return settings.catchHighRoller;
  return settings.catchOther;
}

const BUCKET_LABELS = {
  daily: 'Daily Drop',
  highroller: 'High Roller',
  other: 'Other'
};

const SITE_LABELS = { com: 'Stake.com', us: 'Stake.us' };

function cleanHost(domain) {
  return String(domain || 'stake.com')
    .trim()
    .replace(/^https?:\/\//, '')
    .replace(/\/+$/, '');
}

// The VIP modal, opened on the progress tab where the reload claim lives.
function vipUrl(domain) {
  return `https://${cleanHost(domain)}/?tab=progress&modal=vip`;
}

function buildUrl(code, domain, currency) {
  const host = cleanHost(domain);
  const cur = encodeURIComponent(String(currency || 'ltc').trim());
  return `https://${host}/settings/offers?type=drop&code=${encodeURIComponent(code)}` +
         `&currency=${cur}&modal=redeemBonus`;
}