/*
 * BonusGet background service worker - the shared core.
 *
 * Each site keeps all of its own logic in sites/<site>/<site>-background.js
 * and plugs in with registerSite(). This file only holds what every site
 * shares: settings, the claim log, update checks and the Chrome event wiring.
 */
const chromeNs = globalThis.chrome;
importScripts('common.js');

const SITE_MODULES = [];
// A site module: { boot(), start(), alarm(name), settings(changes), message(msg, sendResponse) }
function registerSite(mod) { SITE_MODULES.push(mod); }
const eachSite = (fn) => SITE_MODULES.forEach((m) => { try { fn(m); } catch (e) { console.error('[bonusget]', e); } });

// Timed claims (reloads, daily bonuses) go into one log the panel shows as history.
async function logClaim(site, what, amount) {
  const { claimLog = [] } = await chromeNs.storage.local.get('claimLog');
  claimLog.unshift({ site, what, amount: amount ?? null, at: Date.now() });
  claimLog.length = Math.min(claimLog.length, 60);
  await chromeNs.storage.local.set({ claimLog });
}

/* ============================================================== updates === */

/*
 * stakecodedrop.com/version.json says what the latest release is. When it's
 * newer than this install, the panel shows a notice with the download link.
 *   { "version": "1.4.0", "url": "https://stakecodedrop.com/download.php", "notes": "..." }
 */
const UPDATE_URL = 'https://stakecodedrop.com/version.json';

function newerVersion(a, b) {   // is a newer than b?
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

async function checkForUpdate() {
  try {
    const r = await fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return;
    const latest = await r.json();
    const current = chromeNs.runtime.getManifest().version;
    const update = latest.version && newerVersion(latest.version, current)
      ? { version: String(latest.version), url: latest.url || 'https://stakecodedrop.com/download.php',
          notes: latest.notes || '' }
      : null;
    await chromeNs.storage.local.set({ update });
  } catch { /* offline or site down - try again later */ }
}

/* ============================================================== sites === */

importScripts(
  'sites/stake/stake-background.js',
  'sites/thrill/thrill-background.js',
  'sites/rainbet/rainbet-background.js'
);

/* ========================================================== lifecycle === */

chromeNs.alarms.create('update-check', { periodInMinutes: 180 });
chromeNs.alarms.onAlarm.addListener((a) => {
  if (a.name === 'update-check') checkForUpdate();
  else eachSite((m) => m.alarm?.(a.name));
});

chromeNs.runtime.onStartup.addListener(() => eachSite((m) => m.start?.()));
chromeNs.runtime.onInstalled.addListener(() => eachSite((m) => m.start?.()));

chromeNs.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') eachSite((m) => m.settings?.(changes));
});

chromeNs.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  for (const m of SITE_MODULES) {
    const r = m.message?.(msg, sendResponse, sender);
    if (r !== undefined) return r;
  }
  return false;
});

// Clicking the toolbar icon opens BonusGet in Chrome's side panel.
chromeNs.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

eachSite((m) => m.boot?.());
checkForUpdate();
