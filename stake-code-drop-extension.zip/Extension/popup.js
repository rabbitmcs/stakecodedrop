// Stake Code Drop — popup
//
// There is no login. The extension starts claiming the moment it's installed,
// so this popup only exposes settings: which drop types to watch, which Stake
// mirror to open.
//
// Drop types are independent toggles now — any combination of the three, but
// never zero, since an empty selection would mean the extension watches
// nothing at all.

const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const filterBtns = document.querySelectorAll('.filter-btn');
const filterError = document.getElementById('filter-error');
const lastDropEl = document.getElementById('last-drop');
const domainSelect = document.getElementById('domain-select');
const customDomainRow = document.getElementById('custom-domain-row');
const customDomainInput = document.getElementById('custom-domain-input');
const saveDomainBtn = document.getElementById('save-domain-btn');
const domainError = document.getElementById('domain-error');

const ALL_TYPES = ['normal', 'highroller', 'random'];

const KNOWN_DOMAINS = [
  'stake.com', 'stake.bet', 'stake.games', 'stake.pet', 'stake.mba',
  'stake.ac', 'stake.jp', 'stake.bz', 'stake.ceo', 'stake.krd',
  'staketr.com', 'stake.br',
];

let lastDropTimer = null;
let filterErrorTimer = null;
let selectedTypes = ALL_TYPES.slice();

function showDomainError(msg) { domainError.textContent = msg; domainError.style.display = 'block'; }
function hideDomainError() { domainError.style.display = 'none'; }

function showFilterError(msg) {
  filterError.textContent = msg;
  filterError.style.display = 'block';
  clearTimeout(filterErrorTimer);
  filterErrorTimer = setTimeout(() => { filterError.style.display = 'none'; }, 2500);
}

function setStatus(status) {
  const labels = {
    active: 'Watching for drops',
    connecting: 'Starting',
    offline: 'Server unreachable',
  };
  statusDot.className = `status-dot ${status}`;
  statusText.textContent = labels[status] || status;
}

function paintFilters() {
  filterBtns.forEach((btn) => {
    btn.classList.toggle('active', selectedTypes.includes(btn.dataset.type));
  });
}

// Old builds stored a single string ('both' | 'normal' | 'highroller' |
// 'random'). Map it forward the first time this popup opens.
function normaliseTypes(types, legacy) {
  if (Array.isArray(types)) {
    const clean = types.filter((t) => ALL_TYPES.includes(t));
    if (clean.length) return clean;
  }
  if (legacy && legacy !== 'both' && ALL_TYPES.includes(legacy)) return [legacy];
  return ALL_TYPES.slice();
}

function timeAgo(unixSeconds) {
  const diff = Math.max(0, Math.floor(Date.now() / 1000) - unixSeconds);
  if (diff < 60) return 'just now';
  if (diff < 3600) {
    const m = Math.floor(diff / 60);
    return `${m} minute${m === 1 ? '' : 's'} ago`;
  }
  const h = Math.floor(diff / 3600);
  return `${h} hour${h === 1 ? '' : 's'} ago`;
}

function loadLastDrop() {
  fetch('https://stakecodedrop.com/latest.php')
    .then((r) => r.json())
    .then((data) => {
      if (!data.created_at) {
        lastDropEl.textContent = 'No drops caught yet';
        return;
      }
      lastDropEl.innerHTML = `Last drop: <strong>${timeAgo(data.created_at)}</strong>`;
    })
    .catch(() => {
      lastDropEl.textContent = '';
    });
}

function applyDomainToUI(domain) {
  if (KNOWN_DOMAINS.includes(domain)) {
    domainSelect.value = domain;
    customDomainRow.style.display = 'none';
    saveDomainBtn.style.display = 'none';
  } else {
    domainSelect.value = '__custom__';
    customDomainRow.style.display = 'flex';
    customDomainInput.value = domain;
    saveDomainBtn.style.display = 'block';
  }
}

// A simple hostname shape check — not full validation, just enough to catch
// obvious typos before we go request a real browser permission for it.
function looksLikeDomain(value) {
  return /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i.test(value);
}

chrome.storage.local.get(
  ['status', 'type_filters', 'type_filter', 'stake_domain'],
  ({ status, type_filters, type_filter, stake_domain }) => {
    setStatus(status || 'connecting');
    selectedTypes = normaliseTypes(type_filters, type_filter);
    paintFilters();
    applyDomainToUI(stake_domain || 'stake.com');
    loadLastDrop();
    lastDropTimer = setInterval(loadLastDrop, 30000);
  }
);

window.addEventListener('unload', () => {
  if (lastDropTimer) clearInterval(lastDropTimer);
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.status) setStatus(changes.status.newValue);
});

filterBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.type;
    const on = selectedTypes.includes(type);

    if (on && selectedTypes.length === 1) {
      showFilterError('Keep at least one drop type selected.');
      return;
    }

    selectedTypes = on
      ? selectedTypes.filter((t) => t !== type)
      : ALL_TYPES.filter((t) => t === type || selectedTypes.includes(t));

    paintFilters();
    chrome.runtime.sendMessage({ type: 'SET_FILTER', filters: selectedTypes });
  });
});

domainSelect.addEventListener('change', () => {
  hideDomainError();
  if (domainSelect.value === '__custom__') {
    customDomainRow.style.display = 'flex';
    saveDomainBtn.style.display = 'block';
    customDomainInput.focus();
    return;
  }
  customDomainRow.style.display = 'none';
  saveDomainBtn.style.display = 'none';
  chrome.runtime.sendMessage({ type: 'SET_DOMAIN', domain: domainSelect.value });
});

// Custom domains need a real, user-granted permission before content.js can
// run there — chrome.permissions.request only works from a direct user
// gesture, which this click is.
saveDomainBtn.addEventListener('click', () => {
  hideDomainError();
  const domain = customDomainInput.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');

  if (!domain) return showDomainError('Enter a domain.');
  if (!looksLikeDomain(domain)) return showDomainError('That doesn\'t look like a valid domain.');

  saveDomainBtn.disabled = true;
  saveDomainBtn.textContent = 'Requesting permission...';

  chrome.permissions.request(
    { origins: [`https://${domain}/*`] },
    (granted) => {
      saveDomainBtn.disabled = false;
      saveDomainBtn.textContent = 'Use this domain';
      if (!granted) {
        showDomainError('Permission denied — domain not saved.');
        return;
      }
      chrome.runtime.sendMessage({ type: 'SET_DOMAIN', domain });
      customDomainInput.value = domain;
    }
  );
});