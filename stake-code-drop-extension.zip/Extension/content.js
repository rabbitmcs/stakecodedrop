// Stake Code Drop — claim page auto-clicker
// Runs only on a stake.com offers URL opened by this extension (code + modal
// params present). Waits for the Claim Bonus button, then clicks it after a
// short delay so the page's own verification widget has time to finish
// loading first — clicking too early throws inside Stake's own JS.

(function () {
  'use strict';

  const CLAIM_SELECTOR = '[data-testid="claim-drop"]';
  const MAX_WAIT_MS = 20000;   // give up looking for the button after this long
  const POLL_MS = 200;         // fallback check interval alongside the observer
  const CLICK_DELAY_MS = 4000; // wait this long after the button appears before clicking

  const params = new URLSearchParams(window.location.search);
  const code = params.get('code');
  const modal = params.get('modal');

  // Only act on a genuine bonus-claim navigation from this extension.
  if (!code || modal !== 'redeemBonus') return;

  let buttonFound = false;
  const startedAt = Date.now();

  function notify(title, message) {
    try {
      chrome.runtime.sendMessage({ type: 'NOTIFY', title, message });
    } catch (e) {
      // extension context may be gone — not fatal
    }
  }

  function cleanup() {
    clearInterval(poll);
    observer.disconnect();
  }

  function clickButton(btn) {
    btn.click();
    console.log(`[StakeCodeDrop] Clicked Claim Bonus for ${code}`);
    notify('Bonus claim submitted', `Code ${code} — check your balance.`);
  }

  function tryFindButton() {
    if (buttonFound) return true;

    const btn = document.querySelector(CLAIM_SELECTOR);
    if (!btn) return false;
    if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;

    buttonFound = true;
    cleanup();
    setTimeout(() => clickButton(btn), CLICK_DELAY_MS);
    return true;
  }

  function giveUp() {
    if (buttonFound) return;
    buttonFound = true;
    console.warn(`[StakeCodeDrop] Claim button never appeared for ${code}`);
    notify('Could not auto-claim', `Claim ${code} manually — button did not load.`);
    cleanup();
  }

  const poll = setInterval(() => {
    if (tryFindButton()) return;
    if (Date.now() - startedAt > MAX_WAIT_MS) giveUp();
  }, POLL_MS);

  const observer = new MutationObserver(() => tryFindButton());
  observer.observe(document.body, { childList: true, subtree: true });

  tryFindButton();
})();
