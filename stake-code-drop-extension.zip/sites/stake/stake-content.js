// Auto-click the Stake "Claim Bonus" button the moment the redeem modal opens.
const SELECTOR = 'button[data-testid="claim-drop"]';

function clickClaimButton() {
  const button = document.querySelector(SELECTOR);
  if (button && !button.disabled) {
    button.click();
    console.log('[BonusGet] Clicked "Claim Bonus" button.');
  }
}

// 1. Initial check on load
clickClaimButton();

// 2. Continuous monitoring for dynamic re-renders (SPAs)
const observer = new MutationObserver(() => {
  clickClaimButton();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});
// Pass the result of the claim (seen by stake_hook.js) back to the extension.
window.addEventListener('message', (e) => {
  if (e.source !== window || !e.data || e.data.__bonusget !== 'claim') return;
  // After the extension is reloaded, scripts left in open tabs lose their link
  // to it; skip quietly instead of throwing.
  if (!chrome.runtime?.id) return;
  try {
    chrome.runtime.sendMessage({ type: 'stakeClaimResult', code: e.data.code, ok: e.data.ok, error: e.data.error, host: location.host })
      .catch(() => {});
  } catch {}
});
