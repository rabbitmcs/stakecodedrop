// Runs in the Stake page itself (MAIN world) so it can see the site's own
// claim request. When the redeem page claims a code, Stake's reply says
// whether it worked; that result is passed to autoclick.js, which tells the
// extension. This is what lets the history show real claims, not just opens.
(() => {
  const origFetch = window.fetch;
  window.fetch = async function (input, init) {
    const res = await origFetch.apply(this, arguments);
    try {
      const body = init && typeof init.body === 'string' ? init.body : '';
      // Drop codes use claimConditionBonusCode; other codes use claimBonusCode.
      const req = /claim\w*BonusCode/i.test(body) ? JSON.parse(body) || {} : null;
      // Only the actual claim (a mutation) counts. The page also runs lookup
      // queries with similar names when the redeem box opens; those succeed even
      // when the claim later fails (too slow, wager not met), which used to be
      // recorded as a claim.
      if (req && /^\s*mutation\b/.test(req.query || '')) {
        const vars = req.variables || {};
        res.clone().json().then((j) => {
          const data = (j && j.data) || {};
          const ok = Object.values(data).some((v) => v != null && v !== false) && !(j.errors && j.errors.length);
          window.postMessage({
            __bonusget: 'claim', code: vars.code || '', ok,
            error: ok ? null : ((j.errors && j.errors[0] && j.errors[0].message) || 'Claim failed')
          }, '*');
        }).catch(() => {});
      }
    } catch (e) { /* never get in the site's way */ }
    return res;
  };
})();
