/*
 * Stake.com + Stake.us, everything that runs in the background:
 *   - drop codes from the Firebase feed (opens the redeem page the instant one lands)
 *   - VIP reloads
 *   - the Stake.us daily bonus
 * Loaded by background.js; shares its scope (chromeNs, getSettings, logClaim...).
 */

/* ================================================================ stake === */

const SEEN_LIMIT = 2000;
const STALE_MS = 75_000;      // no traffic for this long => assume the stream died
const STATUS_THROTTLE = 5000; // don't hammer storage on every keep-alive

// Anonymous heartbeat, so the site can show how many installs are live.
// One random id, no account, nothing that points back to a person.
const PING_URL = 'https://stakecodedrop.com/stream/ping.php';

// Stake.com and Stake.us each get their own independent stream. State is kept
// in per-site maps keyed by site id so enabling one never disturbs the other.
const stream = {};
for (const s of SITES) {
  stream[s.id] = {
    controller: null,
    connected: false,
    connecting: false,
    backoff: 1000,
    lastEventAt: 0,
    lastStatusWrite: 0
  };
}

// Seen keys are per-site: the two feeds number their records independently,
// so a shared set would let one feed mask the other's codes.
async function loadState(siteId) {
  const seenKey = `seen_${siteId}`;
  const primedKey = `primed_${siteId}`;
  const got = await chromeNs.storage.local.get({ [seenKey]: [], [primedKey]: false });
  return { seen: new Set(got[seenKey]), primed: got[primedKey] };
}

async function saveSeen(siteId, seenSet) {
  await chromeNs.storage.local.set({
    [`seen_${siteId}`]: Array.from(seenSet).slice(-SEEN_LIMIT)
  });
}

async function pushHistory(entry) {
  const { history = [] } = await chromeNs.storage.local.get({ history: [] });
  history.unshift(entry);
  await chromeNs.storage.local.set({ history: history.slice(0, 40) });
}

// Flat keys, no read-modify-write, keyed per site so the two Stake streams
// never clobber each other. A numeric "generation" guards against a stale
// connection updating status after it has been torn down.
async function setSiteStatus(siteId, patch) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) out[`st_${siteId}_${k}`] = v;
  await chromeNs.storage.local.set(out);
}

async function installId() {
  const { installId } = await chromeNs.storage.local.get({ installId: null });
  if (installId) return installId;
  const fresh = crypto.randomUUID();
  await chromeNs.storage.local.set({ installId: fresh });
  return fresh;
}

/*
 * Sent as text/plain so the browser treats it as a simple request and skips
 * the CORS preflight. Failures are ignored - this is telemetry, and it must
 * never interfere with catching codes.
 */
async function ping() {
  try {
    const settings = await getSettings();
    const active = SITES.filter((s) => siteEnabled(s.id, settings)).map((s) => s.id);
    if (!active.length) return;
    await fetch(PING_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body: JSON.stringify({
        install_id: await installId(),
        version: chromeNs.runtime.getManifest().version,
        site: active.join(',')
      })
    });
  } catch (e) {
    /* offline, blocked, server down - none of it matters here */
  }
}

// Old builds kept a pinned redeem tab open; close any that are left over.
chromeNs.storage.local.get(['pk_com_tab', 'pk_us_tab']).then((o) => {
  for (const t of Object.values(o)) if (t != null) chromeNs.tabs.remove(t).catch(() => {});
  chromeNs.storage.local.remove(['pk_com_tab', 'pk_us_tab']);
});

async function fire(siteId, key, record, settings) {
  const cfg = siteConfig(siteId, settings);
  const bucket = classify(record, settings);
  const code = String(record.code);
  const url = buildUrl(code, cfg.domain, cfg.currency);

  const entry = {
    site: siteId,
    key: String(key),
    code,
    bucket,
    amount: record.amount ?? null,
    wager: record.wager ?? null,
    url,
    at: Date.now(),
    opened: false
  };

  if (!wanted(bucket, settings)) {
    await pushHistory(entry);
    return;
  }

  chromeNs.tabs.create({ url, active: !settings.openInBackground });
  entry.opened = true;

  if (settings.notify) {
    chromeNs.notifications.create(`stake-drop-${siteId}-${key}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: `${BUCKET_LABELS[bucket]} - ${code}`,
      message: record.amount
        ? `$${record.amount}${record.wager ? `  |  wager ${record.wager}` : ''}`
        : 'Opening redeem page',
      priority: 2
    });
  }

  await pushHistory(entry);
  await setSiteStatus(siteId, { lastDropAt: Date.now(), lastCode: code });
}

async function handleRecord(siteId, key, record, state, settings) {
  key = String(key);
  if (!record || typeof record !== 'object') return false;
  if (state.seen.has(key)) return false;
  if (!record.code) return false;

  state.seen.add(key);

  if (record.active === false) return false;

  const posted = record.posted_at || record.timestamp || 0;
  if (posted && settings.maxAgeSeconds > 0) {
    const age = Date.now() / 1000 - posted;
    if (age > settings.maxAgeSeconds) return false;
  }

  // Remember it before acting, so a stuck claim can't make it fire again on reconnect.
  await saveSeen(siteId, state.seen);
  await fire(siteId, key, record, settings);
  return true;
}

/*
 * One parsed SSE event. Firebase wraps everything as
 *   {"path": "/25169", "data": {...}}
 * path "/" is a full snapshot (first connect or after a reconnect); anything
 * else is a single record keyed by that path.
 */
async function stakeDispatch(siteId, eventName, payload) {
  const st = stream[siteId];
  st.lastEventAt = Date.now();
  if (st.lastEventAt - st.lastStatusWrite > STATUS_THROTTLE) {
    st.lastStatusWrite = st.lastEventAt;
    await setSiteStatus(siteId, { lastEventAt: st.lastEventAt });
  }

  if (eventName === 'keep-alive') return;
  if (eventName !== 'put' && eventName !== 'patch') return;
  if (!payload || typeof payload !== 'object') return;

  const path = payload.path || '/';
  const data = payload.data;
  if (data === null || data === undefined) return;

  const settings = await getSettings();
  if (!siteEnabled(siteId, settings)) return;

  const state = await loadState(siteId);

  if (path === '/') {
    if (typeof data !== 'object') return;

    // First connect for this feed: remember what exists, act on none of it.
    if (!state.primed) {
      for (const k of Object.keys(data)) state.seen.add(String(k));
      await saveSeen(siteId, state.seen);
      await chromeNs.storage.local.set({ [`primed_${siteId}`]: true });
      await setSiteStatus(siteId, { primedCount: state.seen.size });
      return;
    }

    for (const [k, v] of Object.entries(data)) {
      await handleRecord(siteId, k, v, state, settings);
    }
    await saveSeen(siteId, state.seen);
    return;
  }

  const key = path.replace(/^\/+/, '').split('/')[0];
  if (!key) return;
  await handleRecord(siteId, key, data, state, settings);
  await saveSeen(siteId, state.seen);
}

// Stake codes now come from the StakeCodeDrop hub, over the same WebSocket as
// Thrill and Rainbet (see thrill-background.js). The hub reads the community
// Firebase feed and relays its raw put/patch events, so stakeDispatch() above
// is unchanged. A site counts as "connected" while the hub socket is open.
async function stakeConnect(siteId) {
  const st = stream[siteId];
  if (!st) return;

  const settings = await getSettings();
  if (!siteEnabled(siteId, settings)) {
    st.connected = false;
    await setSiteStatus(siteId, { connected: false, note: 'off' });
    return;
  }

  thrillConnect(); // no-op if the hub socket is already open or opening
  if (thrillWs && thrillWs.readyState === WebSocket.OPEN) {
    const wasConnected = st.connected;
    st.connected = true;
    st.connecting = false;
    st.lastEventAt = Date.now();
    st.lastStatusWrite = st.lastEventAt;
    if (!wasConnected) {
      await setSiteStatus(siteId, {
        connected: true, connectedAt: Date.now(), note: '', lastEventAt: st.lastEventAt
      });
    }
  } else {
    st.connected = false;
    await setSiteStatus(siteId, { connected: false, note: '' });
  }
}

function stakeDisconnect(siteId) {
  const st = stream[siteId];
  if (!st) return;
  st.connected = false;
  st.connecting = false;
}

// Re-check the site and ask the hub for a fresh snapshot of the feed.
function stakeRestart(siteId) {
  stakeDisconnect(siteId);
  setTimeout(async () => {
    await stakeConnect(siteId);
    try { if (thrillWs && thrillWs.readyState === WebSocket.OPEN) thrillWs.send('{"t":"stake"}'); } catch (e) { /* closed */ }
  }, 60);
}

async function stakeWatchdog(siteId) {
  const st = stream[siteId];
  if (!st) return;
  const settings = await getSettings();
  if (!siteEnabled(siteId, settings)) {
    if (st.connected) stakeDisconnect(siteId);
    await setSiteStatus(siteId, { connected: false, note: 'off' });
    return;
  }
  if (!st.connected) return stakeConnect(siteId);
}

// Called by the hub socket (thrill-background.js).
async function stakeOnRelay(siteId, eventName, payload) {
  if (!stream[siteId]) return;
  try {
    await stakeDispatch(siteId, eventName, payload);
  } catch (e) {
    // One bad record must never take the feed down.
    console.error(`[bonusget:stake:${siteId}]`, e);
  }
}

function stakeRelayStatus(open) {
  SITES.forEach((s) => {
    if (open) {
      stakeConnect(s.id);
    } else {
      stakeDisconnect(s.id);
      getSettings().then((settings) =>
        setSiteStatus(s.id, { connected: false, note: siteEnabled(s.id, settings) ? '' : 'off' }));
    }
  });
}

/* =============================================================== reload === */

/*
 * VIP reloads ("faucets" inside Stake's API). The API says exactly when the
 * next one is due (lastClaim + claimInterval), so nothing is scraped off the
 * page. The claim itself is done by clicking in a background tab, because
 * Stake wants its Cloudflare check passed for that.
 */
const RELOAD_Q = 'query VipMeta { user { id reload: faucet { id active value ' +
                 'claimInterval lastClaim expireAt } } }';
const RELOAD_REWARD_SEL =
  '[data-testid="modal-vip"] button[data-testid="vip-reward-claim-reload"], ' +
  '[data-testid="modal-vip"] button[data-analytics="vip-reward-claim-reload"]';
const RELOAD_MODAL_SEL =
  'button[data-testid="claim-reload"], button[data-analytics="claim-reload"]';
const RELOAD_BUFFER_MS = 5000;
const RELOAD_RETRY_MS = 10 * 60 * 1000;
const RELOAD_IDLE_MS = 6 * 60 * 60 * 1000; // account has no reload: look again later
const reloadBusy = {};

const reloadEnabled = (id, s) => !!s[`${id}Reload`];

async function setReload(id, patch) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) out[`rl_${id}_${k}`] = v;
  await chromeNs.storage.local.set(out);
}

function reloadDueAt(info) {
  const last = info && info.lastClaim ? Date.parse(info.lastClaim) : NaN;
  if (Number.isNaN(last)) return Date.now();
  return last + (info.claimInterval || 0); // claimInterval is in ms
}

async function sessionToken(host) {
  try {
    const c = await chromeNs.cookies.get({ url: `https://${host}/`, name: 'session' });
    return c ? c.value : null;
  } catch {
    return null;
  }
}

async function reloadQuery(host) {
  const token = await sessionToken(host);
  if (!token) return { error: 'login' };
  try {
    const r = await fetch(`https://${host}/_api/graphql`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'content-type': 'application/json',
        'x-access-token': token,
        'x-language': 'en',
        'x-operation-name': 'VipMeta',
        'x-operation-type': 'query'
      },
      body: JSON.stringify({ query: RELOAD_Q, operationName: 'VipMeta', variables: {} })
    });
    if (r.status === 401 || r.status === 403) return { error: 'login' };
    const j = await r.json();
    if (j.errors) return { error: j.errors[0]?.message || 'API error' };
    return { info: j.data?.user?.reload || null };
  } catch (e) {
    return { error: String(e.message || e) };
  }
}

function waitForTabLoad(tabId, timeout) {
  return new Promise((resolve, reject) => {
    const done = (fn, arg) => {
      clearTimeout(timer);
      chromeNs.tabs.onUpdated.removeListener(listener);
      fn(arg);
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') done(resolve);
    };
    const timer = setTimeout(() => done(reject, new Error('page load timed out')), timeout);
    chromeNs.tabs.onUpdated.addListener(listener);
    chromeNs.tabs.get(tabId).then((t) => { if (t.status === 'complete') done(resolve); }).catch(() => {});
  });
}

// Runs inside the Stake tab: click the reload reward, then the modal's Claim.
async function reloadClickTask(rewardSel, modalSel) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ready = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2 && !el.disabled &&
           el.getAttribute('aria-disabled') !== 'true';
  };
  const press = (el) => {
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    el.click();
  };
  const waitFor = async (sel, ms) => {
    for (let t = 0; t < ms; t += 500) {
      const el = document.querySelector(sel);
      if (ready(el)) return el;
      await sleep(500);
    }
    return null;
  };

  const reward = await waitFor(rewardSel, 30000);
  if (!reward) return { claimed: false, note: 'Claim button not found' };
  press(reward);
  const confirm = await waitFor(modalSel, 20000);
  if (!confirm) return { claimed: false, note: 'Claim popup didn’t appear' };
  press(confirm);
  await sleep(3000);
  return { claimed: true };
}

async function reloadClaimInTab(host) {
  const tab = await chromeNs.tabs.create({ url: vipUrl(host), active: false });
  try {
    await waitForTabLoad(tab.id, 45000);
    const [res] = await chromeNs.scripting.executeScript({
      target: { tabId: tab.id },
      func: reloadClickTask,
      args: [RELOAD_REWARD_SEL, RELOAD_MODAL_SEL]
    });
    return res?.result || { claimed: false, note: 'No reply from the page' };
  } finally {
    chromeNs.tabs.remove(tab.id).catch(() => {});
  }
}

async function reloadSchedule(id, at, extra = {}) {
  await chromeNs.alarms.create(`reload-${id}`, { when: Math.max(at, Date.now() + 1000) });
  await setReload(id, { next: at, note: '', ...extra });
}

async function reloadStop(id) {
  await chromeNs.alarms.clear(`reload-${id}`);
  await setReload(id, { state: 'off', next: 0, note: '' });
}

async function reloadCheck(id) {
  if (reloadBusy[id]) return;
  reloadBusy[id] = true;
  try {
    const settings = await getSettings();
    if (!reloadEnabled(id, settings)) return reloadStop(id);
    const host = cleanHost(siteConfig(id, settings).domain);
    await setReload(id, { state: 'checking', note: '' });

    const q = await reloadQuery(host);
    if (q.error === 'login') {
      return reloadSchedule(id, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: `Log in to ${host}` });
    }
    if (q.error) {
      return reloadSchedule(id, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: q.error });
    }
    const info = q.info;
    const expired = info?.expireAt && Date.parse(info.expireAt) < Date.now();
    if (!info || !info.active || expired) {
      return reloadSchedule(id, Date.now() + RELOAD_IDLE_MS, { state: 'none', note: 'No reload on this account' });
    }

    const due = reloadDueAt(info);
    if (due > Date.now() + 2000) {
      return reloadSchedule(id, due + RELOAD_BUFFER_MS, { state: 'waiting', value: info.value ?? null, period: info.claimInterval || 0 });
    }

    // Due now.
    await setReload(id, { state: 'claiming' });
    const res = await reloadClaimInTab(host);
    await new Promise((r) => setTimeout(r, 2000));
    const after = await reloadQuery(host);
    const nextDue = after.info ? reloadDueAt(after.info) : 0;

    if (nextDue > Date.now() + 2000) {
      const countKey = `rl_${id}_count`;
      const { [countKey]: count = 0 } = await chromeNs.storage.local.get(countKey);
      await setReload(id, { lastClaimAt: Date.now(), count: count + 1, lastAmount: info.value ?? null });
      await logClaim(id, 'VIP reload', info.value ?? null);
      if (settings.reloadNotify) {
        chromeNs.notifications.create(`reload-${id}-${Date.now()}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: `${SITE_LABELS[id]} reload claimed`,
          message: info.value ? `$${info.value}` : 'Next one scheduled',
          priority: 1
        });
      }
      return reloadSchedule(id, nextDue + RELOAD_BUFFER_MS, { state: 'waiting', value: after.info.value ?? null, period: after.info.claimInterval || 0 });
    }
    return reloadSchedule(id, Date.now() + RELOAD_RETRY_MS, {
      state: 'error', note: res.claimed ? 'Claim didn’t register, retrying' : res.note
    });
  } catch (e) {
    await reloadSchedule(id, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: String(e.message || e) });
  } finally {
    reloadBusy[id] = false;
  }
}

/* ========================================================= daily bonus === */

/*
 * Stake.us gives a free daily bonus every 24h after the last claim. The API
 * reports lastClaim, so the next one is scheduled exactly; the claim is a
 * click in a background tab (it goes through Stake's Cloudflare check).
 */
const DAILY_Q = 'query ClaimDailyBonusMeta { user { id dailyBonus { id amounts { currency amount } ' +
                'active lastClaim } } }';
const DAILY_EVERY_MS = 24 * 60 * 60 * 1000;
let dailyBusy = false;

async function setDaily(patch) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) out[`dl_${k}`] = v;
  await chromeNs.storage.local.set(out);
}

async function dailyQuery(host) {
  const token = await sessionToken(host);
  if (!token) return { error: 'login' };
  try {
    const r = await fetch(`https://${host}/_api/graphql`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'content-type': 'application/json',
        'x-access-token': token,
        'x-language': 'en',
        'x-operation-name': 'ClaimDailyBonusMeta',
        'x-operation-type': 'query'
      },
      body: JSON.stringify({ query: DAILY_Q, operationName: 'ClaimDailyBonusMeta', variables: {} })
    });
    if (r.status === 401 || r.status === 403) return { error: 'login' };
    const j = await r.json();
    if (j.errors) return { error: j.errors[0]?.message || 'API error' };
    return { info: j.data?.user?.dailyBonus || null };
  } catch (e) {
    return { error: String(e.message || e) };
  }
}

function dailyDueAt(info) {
  const last = info && info.lastClaim ? Date.parse(info.lastClaim) : NaN;
  return Number.isNaN(last) ? Date.now() : last + DAILY_EVERY_MS;
}

// Runs inside the Stake.us tab: wait for "Claim Daily Bonus" to be clickable, click it.
async function dailyClickTask() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const find = () => [...document.querySelectorAll('button')]
    .find((b) => /claim daily bonus/i.test(b.innerText || ''));
  for (let t = 0; t < 30000; t += 500) {
    const b = find();
    if (b && !b.disabled && b.getAttribute('aria-disabled') !== 'true') {
      b.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      b.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      b.click();
      await sleep(4000);
      return { claimed: true };
    }
    await sleep(500);
  }
  return { claimed: false, note: find() ? 'Claim button stayed disabled' : 'Claim button not found' };
}

async function dailyClaimInTab(host) {
  const tab = await chromeNs.tabs.create({
    url: `https://${host}/?tab=dailyBonus&currency=btc&modal=wallet`, active: false
  });
  try {
    await waitForTabLoad(tab.id, 45000);
    const [res] = await chromeNs.scripting.executeScript({ target: { tabId: tab.id }, func: dailyClickTask });
    return res?.result || { claimed: false, note: 'No reply from the page' };
  } finally {
    chromeNs.tabs.remove(tab.id).catch(() => {});
  }
}

async function dailySchedule(at, extra = {}) {
  await chromeNs.alarms.create('daily-us', { when: Math.max(at, Date.now() + 1000) });
  await setDaily({ next: at, note: '', ...extra });
}

async function dailyCheck() {
  if (dailyBusy) return;
  dailyBusy = true;
  try {
    const settings = await getSettings();
    if (!settings.usDaily) {
      await chromeNs.alarms.clear('daily-us');
      return setDaily({ state: 'off', next: 0, note: '' });
    }
    const host = cleanHost(settings.usDomain || 'stake.us');
    await setDaily({ state: 'checking', note: '' });

    const q = await dailyQuery(host);
    if (q.error) {
      return dailySchedule(Date.now() + RELOAD_RETRY_MS,
        { state: 'error', note: q.error === 'login' ? `Log in to ${host}` : q.error });
    }
    if (!q.info || !q.info.active) {
      return dailySchedule(Date.now() + RELOAD_IDLE_MS, { state: 'none', note: 'No daily bonus on this account' });
    }
    const due = dailyDueAt(q.info);
    if (due > Date.now() + 2000) {
      return dailySchedule(due + RELOAD_BUFFER_MS, { state: 'waiting' });
    }

    await setDaily({ state: 'claiming' });
    const res = await dailyClaimInTab(host);
    await new Promise((r) => setTimeout(r, 2000));
    const after = await dailyQuery(host);
    const nextDue = after.info ? dailyDueAt(after.info) : 0;

    if (nextDue > Date.now() + 2000) {
      const { dl_count = 0 } = await chromeNs.storage.local.get('dl_count');
      const sc = (q.info.amounts || []).find((a) => a.currency === 'sweeps');
      await setDaily({ lastClaimAt: Date.now(), count: dl_count + 1, lastAmount: sc ? sc.amount : null });
      await logClaim('us', 'Daily bonus', sc ? sc.amount : null);
      if (settings.dailyNotify) {
        chromeNs.notifications.create(`daily-${Date.now()}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'Stake.us daily bonus claimed',
          message: sc ? `${sc.amount} Stake Cash` : 'Next one in 24 hours',
          priority: 1
        });
      }
      return dailySchedule(nextDue + RELOAD_BUFFER_MS, { state: 'waiting' });
    }
    return dailySchedule(Date.now() + RELOAD_RETRY_MS, {
      state: 'error', note: res.claimed ? 'Claim didn’t register, retrying' : res.note
    });
  } catch (e) {
    await dailySchedule(Date.now() + RELOAD_RETRY_MS, { state: 'error', note: String(e.message || e) });
  } finally {
    dailyBusy = false;
  }
}

async function dailyResume() {
  const settings = await getSettings();
  if (!settings.usDaily) return;
  const { dl_next = 0 } = await chromeNs.storage.local.get('dl_next');
  if (dl_next > Date.now()) await chromeNs.alarms.create('daily-us', { when: dl_next });
  else dailyCheck();
}

// Alarms usually survive a browser restart, but not always - rebuild them
// from storage, and catch up on anything that came due while Chrome was shut.
async function reloadResume() {
  const settings = await getSettings();
  for (const s of SITES) {
    if (!reloadEnabled(s.id, settings)) {
      await reloadStop(s.id);
      continue;
    }
    const key = `rl_${s.id}_next`;
    const { [key]: next = 0 } = await chromeNs.storage.local.get(key);
    if (next > Date.now()) {
      await chromeNs.alarms.create(`reload-${s.id}`, { when: next });
    } else {
      reloadCheck(s.id);
    }
  }
}

/* ============================================================ wiring === */

chromeNs.alarms.create('stake-watchdog', { periodInMinutes: 0.5 });
chromeNs.alarms.create('heartbeat', { periodInMinutes: 15 });

registerSite({
  boot() { SITES.forEach((s) => stakeConnect(s.id)); },
  start() {
    SITES.forEach((s) => stakeConnect(s.id));
    ping();
    reloadResume();
    dailyResume();
  },
  alarm(name) {
    if (name === 'stake-watchdog') SITES.forEach((s) => stakeWatchdog(s.id));
    else if (name === 'heartbeat') ping();
    else if (name.startsWith('reload-')) reloadCheck(name.slice(7));
    else if (name === 'daily-us') dailyCheck();
  },
  settings(changes) {
    if ('stakeComEnabled' in changes) stakeRestart('com');
    else if ('stakeUsEnabled' in changes) stakeRestart('us');
    // Site config (domain/currency) changes trigger a reconnect.
    if ('comDomain' in changes || 'comCurrency' in changes) stakeRestart('com');
    if ('usDomain' in changes || 'usCurrency' in changes) stakeRestart('us');
    // Reload toggled (or its site/domain changed): look up the next reload now.
    if ('comReload' in changes || 'stakeComEnabled' in changes || 'comDomain' in changes) reloadCheck('com');
    if ('usReload' in changes || 'stakeUsEnabled' in changes || 'usDomain' in changes) reloadCheck('us');
    if ('usDaily' in changes || 'usDomain' in changes) dailyCheck();
  },
  message(msg, sendResponse) {
    if (msg?.type === 'stakeClaimResult') {
      // Mark the matching history entry with what Stake actually said.
      chromeNs.storage.local.get({ history: [] }).then(({ history }) => {
        const h = history.find((x) => x.code.toLowerCase() === String(msg.code).toLowerCase());
        if (!h) return;   // the claim's own reply is the final word
        h.claimed = !!msg.ok;
        h.error = msg.ok ? null : msg.error;
        h.claimedAt = Date.now();
        return chromeNs.storage.local.set({ history });
      });
      return false;
    }
    if (msg?.type === 'reconnect') {
      SITES.forEach((s) => stakeRestart(s.id));
      sendResponse({ ok: true });
      return false;
    }
    if (msg?.type === 'test') {
      getSettings().then((settings) => {
        const id = msg.site === 'us' || msg.site === 'com' ? msg.site : 'com';
        const url = buildUrl(msg.code || 'testcode123',
                             settings[`${id}Domain`], settings[`${id}Currency`]);
        chromeNs.tabs.create({ url, active: !settings.openInBackground });
        sendResponse({ ok: true, url });
      });
      return true;
    }
    if (msg?.type === 'resetPrime') {
      const wipe = { history: [] };
      for (const s of SITES) {
        wipe[`seen_${s.id}`] = [];
        wipe[`primed_${s.id}`] = false;
      }
      chromeNs.storage.local.set(wipe).then(() => sendResponse({ ok: true }));
      return true;
    }
  }
});
