/*
 * Rainbet, everything that runs in the background:
 *   - bonus codes (Bonus / VIP channels) from the relay
 *   - daily reloads (3x a day) and the daily bonus
 * Loaded by background.js; shares its scope.
 */

/* ============================================================== rainbet === */

/*
 * Rainbet redeems with one POST, authenticated by the user's own rainbet.com
 * login cookie - no tab, no captcha. If the direct request can't use the
 * session, it is retried from inside any open rainbet.com tab.
 */
const RAINBET_MAX_LOG = 40;
const rainbetSeen = new Set();
const rainbetReady = chromeNs.storage.local.get({ rainbetLog: [] })
  .then(({ rainbetLog }) => rainbetLog.filter((e) => e.result !== 'login').forEach((e) => rainbetSeen.add(e.code)));

// Make requests from the extension look like they come from rainbet.com itself.
chromeNs.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [2],
  addRules: [{
    id: 2,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'origin', operation: 'set', value: 'https://rainbet.com' },
        { header: 'referer', operation: 'set', value: 'https://rainbet.com/' }
      ]
    },
    condition: { urlFilter: '||services.rainbet.com/v1/', resourceTypes: ['xmlhttprequest', 'other'], tabIds: [-1] }
  }]
});

/*
 * One way in for every Rainbet API call (codes, reloads, daily bonus).
 *
 * Rainbet's login cookie only lasts about an hour. The site renews it only
 * when one of ITS requests gets turned away, so an open tab doesn't keep it
 * fresh for us. Every attempt below therefore does: request -> if refused,
 * renew the login -> request again.
 *   1. straight from the extension
 *   2. from inside an open rainbet.com tab (exactly the site's own request)
 *   3. no tab open: open rainbet.com quietly in the background, use it, close it
 */
const RB_API = 'https://services.rainbet.com/';
const RB_REFRESH = 'v1/auth/refresh-token';

// Runs anywhere (extension or page): request, renew login on 401, retry once.
async function rbCall(base, path, body, refreshPath) {
  const opts = {
    method: body ? 'POST' : 'GET',
    credentials: 'include',
    headers: { accept: 'application/json', 'x-requested-with': 'rb', ...(body ? { 'content-type': 'application/json' } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {})
  };
  const once = async () => {
    try { const r = await fetch(base + path, opts); return { status: r.status, text: await r.text() }; }
    catch (e) { return { status: 0, error: String(e) }; }
  };
  let r = await once();
  if (r.status === 401) {
    try {
      const ref = await fetch(base + refreshPath, { method: 'POST', credentials: 'include',
        headers: { accept: 'application/json', 'x-requested-with': 'rb' } });
      if (ref.ok) r = await once();
    } catch {}
  }
  return r;
}

async function rbInTab(tabId, path, body) {
  try {
    const [res] = await chromeNs.scripting.executeScript({
      target: { tabId }, func: rbCall, args: [RB_API, path, body || null, RB_REFRESH]
    });
    return res?.result?.status ? res.result : null;
  } catch { return null; }
}

function rbTabLoaded(tabId, timeout) {
  return new Promise((resolve) => {
    const done = () => { clearTimeout(t); chromeNs.tabs.onUpdated.removeListener(on); resolve(); };
    const on = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const t = setTimeout(done, timeout);
    chromeNs.tabs.onUpdated.addListener(on);
  });
}

async function rbApi(path, body) {
  let r = await rbCall(RB_API, path, body, RB_REFRESH);
  if (r.status !== 0 && r.status !== 401 && r.status !== 403) return { ...r, json: thrillParse(r.text) };

  const tabs = await chromeNs.tabs.query({ url: ['https://rainbet.com/*', 'https://*.rainbet.com/*'] });
  for (const t of tabs) {
    if (t.url && t.url.startsWith('https://services.')) continue;
    const x = await rbInTab(t.id, path, body);
    if (x) { r = x; break; }
  }
  if (!tabs.length) {
    let tab = null;
    try {
      tab = await chromeNs.tabs.create({ url: 'https://rainbet.com/', active: false });
      await rbTabLoaded(tab.id, 30000);
      await new Promise((res) => setTimeout(res, 1500));
      const x = await rbInTab(tab.id, path, body);
      if (x) r = x;
    } finally {
      if (tab) chromeNs.tabs.remove(tab.id).catch(() => {});
    }
  }
  return { ...r, json: thrillParse(r.text) };
}

async function rainbetRedeem(rec) {
  await rainbetReady;
  const settings = await getSettings();
  if (!settings.rainbetEnabled) return;
  const vip = rec.tier ? rec.tier === 'vip' : /vip/i.test(rec.channel || '');
  if (vip ? !settings.rainbetVip : !settings.rainbetBonus) return;
  if (!rec.code || rainbetSeen.has(rec.code)) return;
  rainbetSeen.add(rec.code);

  const t0 = Date.now();
  const r = await rbApi('v1/redeem/code', { code: rec.code });
  const ms = Date.now() - t0;
  const body = thrillParse(r.text);
  const ok = r.status >= 200 && r.status < 300 && !body.error;
  const loginNeeded = r.status === 401 || r.status === 403;
  const entry = {
    code: rec.code,
    value: rec.value,
    vip,
    at: Date.now(),
    ms,
    status: r.status,
    result: ok ? 'claimed' : loginNeeded ? 'login' : 'failed',
    message: ok ? 'Claimed' : loginNeeded ? 'Not logged in to rainbet.com' : body.error || r.error || 'Failed'
  };
  if (loginNeeded) rainbetSeen.delete(rec.code);
  const { rainbetLog = [] } = await chromeNs.storage.local.get('rainbetLog');
  rainbetLog.unshift(entry);
  rainbetLog.length = Math.min(rainbetLog.length, RAINBET_MAX_LOG);
  await chromeNs.storage.local.set({ rainbetLog });

  if (settings.rainbetNotify && (ok || loginNeeded)) {
    chromeNs.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: ok ? `Rainbet: claimed ${rec.value ? '$' + rec.value : 'bonus drop'}` : 'Rainbet: please log in',
      message: ok ? `Code ${rec.code} redeemed in ${ms} ms` : 'Log in at rainbet.com to auto-claim codes.'
    });
  }
}

/* ================================================ rainbet daily rewards === */

/*
 * Rainbet's own rewards API gives exact "claimable" timestamps, so nothing is
 * guessed from the "In 3h" text on the page:
 *   GET  v1/rewards/available       -> calendar.claimable, chest_rewards.daily.claimable
 *   POST v1/rewards/calendar-claim  {date: 'all'}   (daily reload, 3x a day)
 *   POST v1/rewards/chest-claim     {type: 'daily'} (daily bonus)
 */
const RB_TIMED = {
  reload: { key: 'rainbetReload', label: 'Rainbet daily reload', claim: ['v1/rewards/calendar-claim', { date: 'all' }],
            pick: (a) => a?.calendar },
  daily: { key: 'rainbetDaily', label: 'Rainbet daily bonus', claim: ['v1/rewards/chest-claim', { type: 'daily' }],
           pick: (a) => a?.chest_rewards?.daily }
};
const rbBusy = {};

const rbRequest = rbApi;

async function setRb(kind, patch) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) out[`rb_${kind}_${k}`] = v;
  await chromeNs.storage.local.set(out);
}

async function rbSchedule(kind, at, extra = {}) {
  await chromeNs.alarms.create(`rb-${kind}`, { when: Math.max(at, Date.now() + 1000) });
  await setRb(kind, { next: at, note: '', ...extra });
}

async function rbCheck(kind) {
  const cfg = RB_TIMED[kind];
  if (!cfg || rbBusy[kind]) return;
  rbBusy[kind] = true;
  try {
    const settings = await getSettings();
    if (!settings[cfg.key]) {
      await chromeNs.alarms.clear(`rb-${kind}`);
      return setRb(kind, { state: 'off', next: 0, note: '' });
    }
    await setRb(kind, { state: 'checking', note: '' });

    const q = await rbRequest('v1/rewards/available');
    if (q.status === 401 || q.status === 403) {
      return rbSchedule(kind, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: 'Log in to rainbet.com' });
    }
    const item = cfg.pick(q.json);
    if (q.status !== 200 || !item) {
      return rbSchedule(kind, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: q.json.error || q.error || 'Couldn’t read rewards' });
    }
    const due = Date.parse(item.claimable);
    if (due > Date.now() + 2000) {
      return rbSchedule(kind, due + RELOAD_BUFFER_MS, { state: 'waiting' });
    }

    await setRb(kind, { state: 'claiming' });
    const c = await rbRequest(cfg.claim[0], cfg.claim[1]);
    const after = cfg.pick((await rbRequest('v1/rewards/available')).json);
    const nextDue = after ? Date.parse(after.claimable) : NaN;

    if (c.status >= 200 && c.status < 300 && !c.json.error) {
      const countKey = `rb_${kind}_count`;
      const { [countKey]: count = 0 } = await chromeNs.storage.local.get(countKey);
      await setRb(kind, { lastClaimAt: Date.now(), count: count + 1, lastAmount: kind === 'reload' ? item.claimable_amount ?? null : null });
      await logClaim('rainbet', kind === 'reload' ? 'Daily reload' : 'Daily bonus', kind === 'reload' ? item.claimable_amount ?? null : null);
      if (settings.rbTimedNotify) {
        const amt = kind === 'reload' ? item.claimable_amount : null;
        chromeNs.notifications.create(`rb-${kind}-${Date.now()}`, {
          type: 'basic', iconUrl: 'icons/icon128.png', priority: 1,
          title: `${cfg.label} claimed`, message: amt ? `$${amt}` : 'Next one scheduled'
        });
      }
    }
    // Nothing to claim yet (e.g. not enough wagered) still counts as "done for
    // this window" - wait for the next claimable time Rainbet gives us.
    const insufficient = c.json.type === 'er_claim_insufficient_amount' || c.json.error === 'er_claim_insufficient_amount';
    if (nextDue > Date.now() + 2000) {
      return rbSchedule(kind, nextDue + RELOAD_BUFFER_MS, { state: 'waiting', note: insufficient ? 'Nothing to claim last time' : '' });
    }
    return rbSchedule(kind, Date.now() + (insufficient ? 60 * 60 * 1000 : RELOAD_RETRY_MS), {
      state: insufficient ? 'waiting' : 'error',
      note: insufficient ? 'Nothing to claim yet' : (c.json.error || c.error || 'Claim failed, retrying')
    });
  } catch (e) {
    await rbSchedule(kind, Date.now() + RELOAD_RETRY_MS, { state: 'error', note: String(e.message || e) });
  } finally {
    rbBusy[kind] = false;
  }
}

async function rbResume() {
  const settings = await getSettings();
  for (const [kind, cfg] of Object.entries(RB_TIMED)) {
    if (!settings[cfg.key]) continue;
    const key = `rb_${kind}_next`;
    const { [key]: next = 0 } = await chromeNs.storage.local.get(key);
    if (next > Date.now()) await chromeNs.alarms.create(`rb-${kind}`, { when: next });
    else rbCheck(kind);
  }
}

/* ============================================================ wiring === */

registerSite({
  start() { rbResume(); },
  alarm(name) { if (name.startsWith('rb-')) rbCheck(name.slice(3)); },
  settings(changes) {
    if ('rainbetReload' in changes) rbCheck('reload');
    if ('rainbetDaily' in changes) rbCheck('daily');
  }
});
