/*
 * Thrill, everything that runs in the background: listens to the cash-drop
 * relay and redeems drops with your own logged-in thrill.com session.
 * Loaded by background.js; shares its scope.
 */

/* =============================================================== thrill === */

const THRILL_RELAY = 'wss://stakecodedrop.com/ws'; // StakeCodeDrop hub: Thrill, Rainbet and Stake
const THRILL_API = 'https://api.thrill.com/reward/v2/players/self/cash-drops';
const THRILL_MAX_LOG = 40;
const NOT_FOUND_RETRIES = 2; // code posted a hair before Thrill has it live
const RETRY_DELAY_MS = 400;
const REPLAY_WINDOW_MS = 30 * 60 * 1000; // on connect, only replay codes this recent

let thrillWs = null;
let thrillRetryMs = 1000;
let thrillKeepalive = null;
const thrillSeen = new Set();
let thrillReady = null;
let thrillAuthBlocked = false; // hub rejected our key; wait for a new one

// First message on every connection: the license key and this device's id.
async function thrillAuthMessage() {
  let { licenseKey = '', deviceId } = await chromeNs.storage.local.get(['licenseKey', 'deviceId']);
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    await chromeNs.storage.local.set({ deviceId });
  }
  return JSON.stringify({ t: 'auth', key: licenseKey, device: deviceId });
}

// A new key was entered: try again straight away.
chromeNs.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.licenseKey) return;
  thrillAuthBlocked = false;
  try { if (thrillWs) thrillWs.close(); } catch {}
  setTimeout(thrillConnect, 300);
});

// Make requests from the extension look like they come from thrill.com itself.
chromeNs.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [1],
  addRules: [
    {
      id: 1,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'origin', operation: 'set', value: 'https://thrill.com' },
          { header: 'referer', operation: 'set', value: 'https://thrill.com/' }
        ]
      },
      condition: {
        urlFilter: '||api.thrill.com/reward/',
        resourceTypes: ['xmlhttprequest'],
        tabIds: [-1]
      }
    }
  ]
});

async function thrillInit() {
  const { thrillLog = [] } = await chromeNs.storage.local.get('thrillLog');
  thrillLog.filter((e) => e.result !== 'login').forEach((e) => thrillSeen.add(e.code));
  const { thrillClaimed = 0 } = await chromeNs.storage.local.get('thrillClaimed');
  setBadge(thrillClaimed);
}
thrillReady = thrillInit();

async function thrillSettings() {
  return getSettings();
}

async function thrillSetStatus(state) {
  await chromeNs.storage.local.set({ thrillStatus: state });
  if (state !== 'connected') {
    chromeNs.action.setBadgeText({ text: '!' });
    chromeNs.action.setBadgeBackgroundColor({ color: '#e0913a' });
  } else {
    const { thrillClaimed = 0 } = await chromeNs.storage.local.get('thrillClaimed');
    setBadge(thrillClaimed);
  }
}

function setBadge(n) {
  chromeNs.action.setBadgeText({ text: n > 0 ? String(n) : '' });
  chromeNs.action.setBadgeBackgroundColor({ color: '#2fbf86' });
}

function thrillConnect() {
  if (thrillAuthBlocked) return;
  if (thrillWs && (thrillWs.readyState === WebSocket.CONNECTING || thrillWs.readyState === WebSocket.OPEN)) return;
  let sock;
  try {
    sock = new WebSocket(THRILL_RELAY);
  } catch {
    return thrillScheduleReconnect();
  }
  thrillWs = sock;
  thrillSetStatus('connecting');
  sock.onopen = () => {
    thrillRetryMs = 1000;
    thrillAuthMessage().then((m) => { if (sock.readyState === WebSocket.OPEN) sock.send(m); });
    thrillSetStatus('connected');
    if (typeof stakeRelayStatus === 'function') stakeRelayStatus(true);
    clearInterval(thrillKeepalive);
    // an outbound message every 20s keeps the service worker alive
    thrillKeepalive = setInterval(() => {
      if (sock.readyState === WebSocket.OPEN) sock.send('{"t":"ping"}');
    }, 20000);
  };
  sock.onmessage = (e) => {
    try {
      thrillOnMessage(JSON.parse(e.data));
    } catch {}
  };
  const down = () => {
    if (thrillWs !== sock) return;
    clearInterval(thrillKeepalive);
    thrillWs = null;
    if (typeof stakeRelayStatus === 'function') stakeRelayStatus(false);
    if (thrillAuthBlocked) {
      thrillSetStatus('unlicensed');
      return; // no point reconnecting until the key changes
    }
    thrillSetStatus('disconnected');
    thrillScheduleReconnect();
  };
  sock.onclose = down;
  sock.onerror = down;
}

function thrillScheduleReconnect() {
  setTimeout(thrillConnect, thrillRetryMs);
  thrillRetryMs = Math.min(thrillRetryMs * 2, 30000);
}

// One hub carries every site: Thrill as "code", Rainbet as "drop", Stake as "stake".
function thrillOnMessage(msg) {
  const fresh = (rec) => Date.now() - Date.parse(rec.posted_at) <= REPLAY_WINDOW_MS;
  if (msg.type === 'auth') {
    chromeNs.storage.local.set({ licenseStatus: msg });
    if (!msg.ok && msg.reason !== 'error') thrillAuthBlocked = true;
  } else if (msg.type === 'code') {
    thrillRedeem(msg);
  } else if (msg.type === 'drop' && msg.site === 'rainbet') {
    rainbetRedeem(msg);
  } else if (msg.type === 'stake' && (msg.site === 'com' || msg.site === 'us')) {
    stakeOnRelay(msg.site, msg.event, msg.payload);
  } else if (msg.type === 'hello') {
    if (Array.isArray(msg.recent)) msg.recent.filter(fresh).forEach(thrillRedeem);
    if (Array.isArray(msg.drops)) msg.drops.filter((d) => d.site === 'rainbet' && fresh(d)).forEach(rainbetRedeem);
  }
}

async function thrillPost(code, currency) {
  try {
    const r = await fetch(THRILL_API, {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ code, currency })
    });
    return { status: r.status, text: await r.text() };
  } catch (e) {
    return { status: 0, error: String(e) };
  }
}

async function thrillPostViaTab(code, currency) {
  const tabs = await chromeNs.tabs.query({ url: 'https://thrill.com/*' });
  for (const t of tabs) {
    try {
      const res = await chromeNs.tabs.sendMessage(t.id, { type: 'thrill_redeem', code, currency });
      if (res && res.status) return res;
    } catch {}
  }
  return null;
}

function thrillParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

async function thrillAttempt(code, currency) {
  let r = await thrillPost(code, currency);
  if (r.status === 0 || r.status === 401 || r.status === 403) {
    const viaTab = await thrillPostViaTab(code, currency);
    if (viaTab) r = viaTab;
  }
  return r;
}

async function thrillRedeem(rec) {
  await thrillReady;
  const settings = await thrillSettings();
  if (!settings.thrillEnabled) return;
  if (rec.valid_till && Date.parse(rec.valid_till) < Date.now()) return;
  if (thrillSeen.has(rec.code)) return;
  thrillSeen.add(rec.code);

  const t0 = Date.now();
  let r = await thrillAttempt(rec.code, settings.thrillCurrency);
  for (let i = 0; i < NOT_FOUND_RETRIES; i++) {
    if (thrillParse(r.text).errorCode !== 'cash_drop_code_not_found_error') break;
    await new Promise((res) => setTimeout(res, RETRY_DELAY_MS));
    r = await thrillAttempt(rec.code, settings.thrillCurrency);
  }
  const ms = Date.now() - t0;
  const body = thrillParse(r.text);
  const ok = r.status >= 200 && r.status < 300;
  const loginNeeded = r.status === 401 || r.status === 403;
  const entry = {
    code: rec.code,
    value: rec.value,
    at: Date.now(),
    ms,
    status: r.status,
    result: ok ? 'claimed' : loginNeeded ? 'login' : 'failed',
    message: ok
      ? body.message || 'Claimed'
      : loginNeeded
      ? 'Not logged in to thrill.com'
      : body.message || body.errorCode || r.error || 'Failed'
  };
  if (loginNeeded) thrillSeen.delete(rec.code);
  const { thrillLog = [] } = await chromeNs.storage.local.get('thrillLog');
  thrillLog.unshift(entry);
  thrillLog.length = Math.min(thrillLog.length, THRILL_MAX_LOG);
  await chromeNs.storage.local.set({ thrillLog });

  if (ok) {
    const { thrillClaimed = 0 } = await chromeNs.storage.local.get('thrillClaimed');
    await chromeNs.storage.local.set({ thrillClaimed: thrillClaimed + 1 });
    setBadge(thrillClaimed + 1);
  }
  if (settings.thrillNotify && (ok || loginNeeded)) {
    chromeNs.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: ok ? `Claimed ${rec.value ? '$' + rec.value : 'cash drop'}` : 'Thrill: please log in',
      message: ok ? `Code ${rec.code} redeemed in ${ms} ms` : 'Log in at thrill.com to auto-claim codes.'
    });
  }
}

/* ============================================================ wiring === */

chromeNs.alarms.create('thrill-keepalive', { periodInMinutes: 0.5 });

registerSite({
  boot() { thrillConnect(); },
  start() { thrillConnect(); },
  alarm(name) { if (name === 'thrill-keepalive') thrillConnect(); },
  settings(changes) {
    if ('thrillEnabled' in changes && changes.thrillEnabled.newValue) thrillConnect();
  }
});
