const $ = (id) => document.getElementById(id);

// Webhook URL for email submission
const EMAIL_WEBHOOK_URL = 'https://n8n.itsrabbit.com/webhook/emailentered';

// Storage key for tracking if email has been submitted
const EMAIL_SUBMITTED_KEY = 'emailSubmitted';

// Every function the extension runs. `opts` lists the settings shown under it.
const FUNCS = [
  { id: 'com-codes', site: 'com', kind: 'codes', label: 'Stake.com', name: 'Claiming Bonus Codes', key: 'stakeComEnabled', opts: ['catch', 'currency', 'actions'] },
  { id: 'com-reload', site: 'com', kind: 'reload', label: 'Stake.com', name: 'Claiming Reloads', key: 'comReload', opts: [] },
  { id: 'us-codes', site: 'us', kind: 'codes', label: 'Stake.us', name: 'Claiming Bonus Codes', key: 'stakeUsEnabled', opts: ['catch', 'actions'] },
  { id: 'us-reload', site: 'us', kind: 'reload', label: 'Stake.us', name: 'Claiming Reloads', key: 'usReload', opts: [] },
  { id: 'us-daily', site: 'us', kind: 'daily', label: 'Stake.us', name: 'Claiming Daily Bonus', key: 'usDaily', opts: [] },
  { id: 'thrill', site: 'thrill', kind: 'thrill', label: 'Thrill', name: 'Claiming Bonus Codes', key: 'thrillEnabled', opts: ['thrillCurrency'] },
  { id: 'rainbet', site: 'rainbet', kind: 'rainbet', label: 'Rainbet', name: 'Claiming Bonus Codes', key: 'rainbetEnabled', opts: ['rbCatch'] },
  { id: 'rb-reload', site: 'rainbet', kind: 'rbreload', label: 'Rainbet', name: 'Claiming Daily Reloads', key: 'rainbetReload', opts: [] },
  { id: 'rb-daily', site: 'rainbet', kind: 'rbdaily', label: 'Rainbet', name: 'Claiming Daily Bonus', key: 'rainbetDaily', opts: [] }
];

// One bell switch drives every notification setting.
const NOTIFY_KEYS = ['notify', 'reloadNotify', 'dailyNotify', 'thrillNotify', 'rainbetNotify', 'rbTimedNotify'];

const SITE_TAG = { com: 'Stake', us: 'Stake.us', thrill: 'Thrill', rainbet: 'Rainbet' };
const SITE_LOGO = { com: 'stake.svg', us: 'stakeus.svg', thrill: 'thrill.svg', rainbet: 'rainbet.svg' };

function siteLogo(site) {
  const wrap = el('span', `tag-logo site-${site}`);
  if (SITE_LOGO[site]) {
    const img = el('img');
    img.src = `logos/${SITE_LOGO[site]}`;
    img.alt = SITE_TAG[site] || site;
    wrap.appendChild(img);
  } else {
    wrap.textContent = SITE_TAG[site] || site;
  }
  return wrap;
}
const SAMPLE = { com: 'stakecom0i2hvswn48olmg', us: 'stakeusgfc8bvdtjqoip3' };

const setPressed = (el, on) => el.setAttribute('aria-pressed', on ? 'true' : 'false');

function ago(ts) {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

function countdown(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, '0');
  return h ? `${h}h ${m}m` : `${m}m ${sec}s`;
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

async function load() {
  const settings = await getSettings();
  const local = await chrome.storage.local.get({
    st_com_connected: false, st_us_connected: false, history: [],
    thrillStatus: 'connecting', thrillLog: [], rainbetLog: [], claimLog: [], collapsedSites: {}, update: null,
    rl_com_period: 0, rl_us_period: 0, rl_com_lastAmount: null, rl_us_lastAmount: null,
    dl_lastAmount: null, rb_reload_lastAmount: null, rb_daily_lastAmount: null,
    rl_com_state: 'off', rl_com_next: 0, rl_com_note: '', rl_com_count: 0,
    rl_us_state: 'off', rl_us_next: 0, rl_us_note: '', rl_us_count: 0,
    dl_state: 'off', dl_next: 0, dl_note: '', dl_count: 0,
    rb_reload_state: 'off', rb_reload_next: 0, rb_reload_note: '', rb_reload_count: 0,
    rb_daily_state: 'off', rb_daily_next: 0, rb_daily_note: '', rb_daily_count: 0
  });
  return { settings, local };
}

// Storage prefix for functions that run on a timer, or null.
function timedPrefix(f) {
  return { reload: `rl_${f.site}_`, daily: 'dl_', rbreload: 'rb_reload_', rbdaily: 'rb_daily_' }[f.kind] || null;
}

// [state class, status text] for one function.
function statusOf(f, { settings, local }) {
  if (!settings[f.key]) return ['idle', 'Off'];

  if (local.thrillStatus === 'unlicensed' && ['codes', 'thrill', 'rainbet'].includes(f.kind)) {
    return ['off', 'License needed'];
  }

  if (f.kind === 'codes') {
    const domain = settings[`${f.site}Domain`] || (f.site === 'us' ? 'stake.us' : 'stake.com');
    return local[`st_${f.site}_connected`] ? ['on', 'On'] : ['off', `Connecting to ${domain}`];
  }

  if (f.kind === 'thrill' || f.kind === 'rainbet') {
    const host = f.kind === 'thrill' ? 'thrill.com' : 'rainbet.com';
    if (local.thrillStatus === 'connected') return ['on', 'On'];
    if (local.thrillStatus === 'connecting') return ['off', `Connecting to ${host}`];
    return ['off', 'Disconnected'];
  }

  const p = timedPrefix(f);
  const what = { daily: 'daily bonus', rbdaily: 'daily bonus', rbreload: 'daily reload' }[f.kind] || 'reload';
  const state = local[p + 'state'];
  const next = local[p + 'next'];
  if (state === 'waiting') {
    return ['on', next > Date.now() ? `Waiting for ${what} · ${countdown(next - Date.now())}`
                                     : `${what[0].toUpperCase() + what.slice(1)} due now`];
  }
  if (state === 'claiming') return ['on', `Claiming ${what}…`];
  if (state === 'error' || state === 'none') return ['off', local[p + 'note'] || 'Retrying soon'];
  return ['idle', 'Checking…'];
}

// How long each timed function's wait is, for the progress ring.
const PERIOD_MS = { daily: 864e5, rbdaily: 864e5, rbreload: 288e5 };

function progressOf(f, local) {
  const p = timedPrefix(f);
  if (!p || local[p + 'state'] !== 'waiting') return null;
  const next = local[p + 'next'];
  const period = local[p + 'period'] || PERIOD_MS[f.kind];
  if (!next || !period) return null;
  return Math.min(1, Math.max(0, 1 - (next - Date.now()) / period));
}

// Signature of a function's latest claim, so a new one can be celebrated.
function lastClaimOf(f, local) {
  const p = timedPrefix(f);
  if (p) return { sig: String(local[p + 'count'] || 0), amount: local[p + 'lastAmount'] };
  if (f.kind === 'codes') {
    const h = local.history.find((x) => (x.site || 'com') === f.site && x.claimed === true);
    return { sig: h ? h.key + ':' + h.at : '', amount: h && h.amount };
  }
  const e = (local[f.kind === 'thrill' ? 'thrillLog' : 'rainbetLog'] || []).find((x) => x.result === 'claimed');
  return { sig: e ? e.code + ':' + e.at : '', amount: e && e.value };
}

// Any claim that didn't go through.
function failReason() { return 'Not claimed'; }

// Every claim from every function, newest first.
function allClaims(local) {
  const items = [];
  for (const h of local.history) {
    // Only a confirmed claim counts; an opened redeem page alone doesn't.
    const note = h.claimed === false ? failReason(h.error) : (h.opened && h.claimed == null ? 'opened' : null);
    items.push({ site: h.site || 'com', what: h.code, amount: h.amount, at: h.at, ok: h.claimed === true, url: h.url, mono: true, note });
  }
  for (const [site, log] of [['thrill', local.thrillLog], ['rainbet', local.rainbetLog]]) {
    for (const e of log) items.push({ site, what: e.code, amount: e.value, at: e.at, ok: e.result === 'claimed', mono: true,
                                      note: e.result === 'login' ? 'log in' : e.result === 'claimed' ? null : failReason(e.message) });
  }
  for (const c of local.claimLog) items.push({ site: c.site, what: c.what, amount: c.amount, at: c.at, ok: true });
  return items.sort((a, b) => b.at - a.at);
}

/* ------------------------------------------------------------------ build --- */

const RING_R = 7;
const RING_C = 2 * Math.PI * RING_R;
const rows = {};      // FUNCS id -> elements
const seenClaim = {}; // FUNCS id -> last claim signature
const binders = [];   // (data) => void, refresh option controls

function chips(defs) {
  const wrap = el('div', 'chips');
  for (const [key, text] of defs) {
    const b = el('button', null, text);
    b.addEventListener('click', () => toggleSetting(key));
    binders.push(({ settings }) => setPressed(b, settings[key]));
    wrap.appendChild(b);
  }
  return wrap;
}

// A dropdown of known values plus "Custom…", which reveals a text box.
function picker(labelText, values, settingKey, placeholder) {
  const field = el('div', 'field');
  field.appendChild(el('label', null, labelText));
  const sel = el('select');
  for (const v of values) { const o = el('option', null, v); o.value = v; sel.appendChild(o); }
  const custom = el('option', null, 'Custom…');
  custom.value = '__custom__';
  sel.appendChild(custom);
  const box = el('input');
  box.type = 'text';
  box.placeholder = placeholder;
  box.hidden = true;
  box.style.marginTop = '8px';
  sel.addEventListener('change', () => {
    if (sel.value === '__custom__') { box.hidden = false; box.focus(); return; }
    save({ [settingKey]: sel.value });
  });
  box.addEventListener('change', () => { const v = box.value.trim(); if (v) save({ [settingKey]: v }); });
  binders.push(({ settings }) => {
    if (document.activeElement === sel || document.activeElement === box) return;
    const cur = settings[settingKey];
    const known = values.includes(cur);
    if (sel.value !== '__custom__' || known) sel.value = known ? cur : '__custom__';
    box.hidden = sel.value !== '__custom__';
    if (!box.hidden && !known) box.value = cur || '';
  });
  field.append(sel, box);
  return field;
}

function optionsFor(f) {
  const box = el('div', 'opts');
  for (const o of f.opts) {
    if (o === 'catch') {
      box.appendChild(chips([['catchDaily', 'Daily Drop'], ['catchHighRoller', 'High Roller'], ['catchOther', 'Other']]));
    } else if (o === 'rbCatch') {
      box.appendChild(chips([['rainbetBonus', 'Bonus Drop'], ['rainbetVip', 'VIP Bonus']]));
    } else if (o === 'currency') {
      const fields = el('div', 'fields' + (f.site === 'com' ? '' : ' one'));
      if (f.site === 'com') fields.appendChild(picker('Domain', KNOWN_DOMAINS.com, 'comDomain', 'your-mirror.com'));
      fields.appendChild(picker('Currency', CURRENCIES[f.site], `${f.site}Currency`, f.site === 'us' ? 'sweeps' : 'ltc'));
      box.appendChild(fields);
    } else if (o === 'thrillCurrency') {
      box.appendChild(picker('Currency', THRILL_CURRENCIES, 'thrillCurrency', 'USDT'));
    } else if (o === 'actions') {
      const a = el('div', 'actions');
      const test = el('button', 'btn cyan', 'Test redeem page');
      test.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'test', site: f.site, code: SAMPLE[f.site] }));
      a.append(test);
      box.appendChild(a);
    }
  }
  return box;
}

// Short "what it's doing" line for the dashboard.
const CATCH_LABELS = [['catchDaily', 'Daily Drop'], ['catchHighRoller', 'High Roller'], ['catchOther', 'Other']];
const RB_LABELS = [['rainbetBonus', 'Bonus'], ['rainbetVip', 'VIP']];

function summaryOf(f, { settings }) {
  const base = f.name;                                    // e.g. "Claiming Reloads"
  if (!settings[f.key]) return { text: base.replace(/^Claiming /, ''), extra: '' };
  const picked = (defs) => defs.filter(([k]) => settings[k]).map(([, l]) => l).join(', ') || 'nothing selected';
  if (f.kind === 'codes') return { text: base, extra: `(${picked(CATCH_LABELS)})` };
  if (f.kind === 'rainbet') return { text: base, extra: `(${picked(RB_LABELS)})` };
  return { text: base, extra: '' };
}

function sites() {
  const out = [];
  for (const f of FUNCS) {
    let s = out.find((x) => x.label === f.label);
    if (!s) out.push((s = { label: f.label, funcs: [] }));
    s.funcs.push(f);
  }
  return out;
}

function ringSvg(cls) {
  return `<svg class="ring ${cls || ''}" viewBox="0 0 18 18"><circle class="track" cx="9" cy="9" r="${RING_R}"/>` +
         `<circle class="bar" cx="9" cy="9" r="${RING_R}" stroke-dasharray="${RING_C}"/></svg>`;
}

const pages = {};   // site label -> its settings page element
const cards = {};   // site label -> its dashboard card

function build() {
  const wrap = $('funcs');
  for (const s of sites()) {
    // Dashboard card: site name, then one status line per function.
    const card = el('button', 'site');
    const head = el('div', 'site-head');
    head.append(el('strong', null, s.label), el('span', 'caret', '›'));
    const sum = el('div', 'site-sum');
    card.append(head, sum);
    card.addEventListener('click', () => showSite(s.label));
    cards[s.label] = card;
    wrap.appendChild(card);

    // Settings page for this site (lives in the right-hand panel).
    const page = el('div', 'site-page');
    page.hidden = true;
    pages[s.label] = page;
    $('detailBody').appendChild(page);

    for (const f of s.funcs) {
      const line = el('div', 'sum-line');
      line.innerHTML = '<span class="dot"></span><span class="sum-text"><strong></strong> <span class="sum-extra"></span></span>' +
                       ringSvg('mini-ring') + '<span class="sum-time"></span><span class="pop"></span>';
      sum.appendChild(line);

      const block = el('div', 'func-block');
      const row = el('div', 'func');
      row.innerHTML = ringSvg() + '<span class="txt"><strong></strong><span class="st"></span></span>' +
        '<button class="qs" role="switch" aria-pressed="false" title="Auto-claim"><span class="sw"></span></button>';
      row.querySelector('strong').textContent = f.name;
      row.querySelector('.qs').addEventListener('click', () => toggleSetting(f.key));
      block.appendChild(row);
      if (f.opts.length) block.appendChild(optionsFor(f));
      page.appendChild(block);

      rows[f.id] = {
        line, dot: line.querySelector('.dot'), sumText: line.querySelector('.sum-text strong'),
        sumExtra: line.querySelector('.sum-extra'), sumTime: line.querySelector('.sum-time'),
        sumRing: line.querySelector('.mini-ring'), sumBar: line.querySelector('.mini-ring .bar'),
        pop: line.querySelector('.pop'),
        row, ring: row.querySelector('.ring'), bar: row.querySelector('.ring .bar'),
        status: row.querySelector('.st'), qs: row.querySelector('.qs')
      };
    }
  }
}

/* ------------------------------------------------- sliding between pages --- */

let current = null;   // site label being shown, or null for the dashboard

function fitHeight() {
  // The dashboard fills the window; history takes whatever height is left.
  const top = $('slider').getBoundingClientRect().top + window.scrollY;
  const avail = Math.floor(window.innerHeight - top);
  const home = $('home');
  const minH = $('funcs').offsetHeight + 230;   // keep the history usable on short windows
  home.style.height = Math.max(avail, minH) + 'px';
  const pane = current ? $('detail') : home;
  $('slider').style.height = (current ? pane.scrollHeight : home.offsetHeight) + 'px';
}
window.addEventListener('resize', () => fitHeight());

function showSite(label) {
  current = label;
  for (const [l, page] of Object.entries(pages)) page.hidden = l !== label;
  $('detailTitle').textContent = label;
  $('track').classList.add('at-detail');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  fitHeight();
}

function showHome() {
  current = null;
  $('track').classList.remove('at-detail');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  fitHeight();
}

/* ----------------------------------------------------------------- render --- */

// Claim moment: the dashboard line flashes green and shows what came in.
function celebrate(r, amount) {
  r.pop.textContent = amount != null && amount !== '' ? `+$${amount}` : 'Claimed!';
  r.line.classList.remove('flash');
  void r.line.offsetWidth;
  r.line.classList.add('flash');
  clearTimeout(r.flashTimer);
  r.flashTimer = setTimeout(() => r.line.classList.remove('flash'), 3200);
}

let historySig = '';

function renderHistory(local) {
  const items = allClaims(local);
  const ok = items.filter((i) => i.ok);
  $('gCount').textContent = ok.length;
  $('gLast').textContent = ok.length ? ago(ok[0].at) : '-';

  const shown = items.slice(0, 50);
  const sig = JSON.stringify(shown.map((i) => [i.site, i.what, i.at, i.ok, Math.round((Date.now() - i.at) / 60000)]));
  if (sig === historySig) return;
  historySig = sig;
  const list = $('gList');
  list.innerHTML = '';
  $('gEmpty').hidden = items.length > 0;
  for (const i of shown) {
    const li = el('li', i.ok ? '' : 'skipped');
    li.append(siteLogo(i.site),
              el('span', 'code' + (i.mono ? ' mono' : ''), i.what),
              el('span', 'meta', (i.note ? i.note + ' · ' : '') + (i.amount ? `$${i.amount} · ` : '') + ago(i.at)));
    if (i.url) li.addEventListener('click', () => chrome.tabs.create({ url: i.url }));
    list.appendChild(li);
  }
}

async function render() {
  const data = await load();
  if (!$('funcs').children.length) {
    build();
    chrome.storage.local.get({ hiddenSites: [] }).then(({ hiddenSites }) => applyHiddenSites(hiddenSites));
  }
  for (const f of FUNCS) {
    const r = rows[f.id];
    const [cls, text] = statusOf(f, data);
    const on = !!data.settings[f.key];
    const prog = progressOf(f, data.local);
    const busy = /^Claiming/.test(text);

    // Dashboard line: status dot first, then what it's doing.
    r.dot.className = 'dot ' + cls + (cls === 'on' ? ' live' : '');
    const sum = summaryOf(f, data);
    r.sumText.textContent = sum.text;
    r.sumExtra.textContent = sum.extra;
    r.line.classList.toggle('off', !on);
    r.line.hidden = !on;   // only active functions show on the dashboard
    r.sumRing.style.display = prog == null ? 'none' : '';
    if (prog != null) r.sumBar.style.strokeDashoffset = String(RING_C * (1 - prog));
    // Countdown (or a problem) after the text; nothing extra when it's simply live.
    const timeText = !on ? '' : prog != null ? text.replace(/^Waiting for [^·]+· /, '')
                   : cls === 'off' || busy || cls === 'idle' ? text : '';
    r.sumTime.textContent = timeText;

    // Settings page row.
    r.row.classList.toggle('busy', busy);
    r.status.textContent = text;
    setPressed(r.qs, on);
    r.ring.style.display = prog == null ? 'none' : '';
    if (prog != null) r.bar.style.strokeDashoffset = String(RING_C * (1 - prog));

    const claim = lastClaimOf(f, data.local);
    if (f.id in seenClaim && claim.sig && claim.sig !== seenClaim[f.id]) celebrate(r, claim.amount);
    seenClaim[f.id] = claim.sig;
  }
  for (const b of binders) b(data);
  setPressed($('bell'), NOTIFY_KEYS.some((k) => data.settings[k]));
  renderHistory(data.local);

  // New version notice.
  const up = data.local.update;
  $('update').hidden = !up;
  if (up) {
    $('update').href = up.url;
    $('updateTitle').textContent = `Update available: v${up.version}`;
    $('updateNotes').textContent = up.notes || `You're on v${chrome.runtime.getManifest().version}`;
  }
  // Sites with nothing switched on show just their name.
  for (const card of Object.values(cards)) {
    card.classList.toggle('none-on', ![...card.querySelectorAll('.sum-line')].some((l) => !l.hidden));
  }
  fitHeight();
}

function save(patch) {
  return new Promise((resolve) => chrome.storage.sync.set(patch, () => render().then(resolve)));
}

function toggleSetting(key) {
  return getSettings().then((s) => save({ [key]: !s[key] }));
}

/* ----------------------------------------------------------- header bits --- */

function applyHiddenSites(hidden) {
  for (const [label, card] of Object.entries(cards)) card.hidden = hidden.includes(label);
  if (typeof fitHeight === 'function') fitHeight();
}

function setupHeader() {

  // Sites dropdown: tick which sites show on the dashboard.
  const menu = $('sitesMenu');
  chrome.storage.local.get({ hiddenSites: [] }).then(({ hiddenSites }) => {
    for (const { label } of sites()) {
      const lab = el('label');
      const box = el('input');
      box.type = 'checkbox';
      box.checked = !hiddenSites.includes(label);
      box.addEventListener('change', async () => {
        const { hiddenSites: h } = await chrome.storage.local.get({ hiddenSites: [] });
        const next = box.checked ? h.filter((x) => x !== label) : [...new Set([...h, label])];
        await chrome.storage.local.set({ hiddenSites: next });
        applyHiddenSites(next);
      });
      lab.append(box, document.createTextNode(label));
      menu.appendChild(lab);
    }
    applyHiddenSites(hiddenSites);
  });
  $('sitesBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.hidden = !menu.hidden;
  });
  menu.addEventListener('click', (e) => e.stopPropagation());
  document.addEventListener('click', () => { menu.hidden = true; });

  $('bell').addEventListener('click', async () => {
    const s = await getSettings();
    const on = !NOTIFY_KEYS.some((k) => s[k]);
    save(Object.fromEntries(NOTIFY_KEYS.map((k) => [k, on])));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setupHeader();
  $('back').addEventListener('click', showHome);
  
  // Ask for a license key until a valid one is saved
  checkLicense();
  renderLicense();
  refreshLicense();
  
  render();
  setInterval(render, 1000);
});

/* ============================================================== license === */

const LICENSE_API = 'https://stakecodedrop.com/stream/license.php';

async function getDeviceId() {
  let { deviceId } = await chrome.storage.local.get('deviceId');
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ deviceId });
  }
  return deviceId;
}

async function checkLicense() {
  const { licenseKey, licenseStatus } = await chrome.storage.local.get({ licenseKey: '', licenseStatus: null });
  if (!licenseKey) return showLicenseModal();
  if (licenseStatus && licenseStatus.ok === false && licenseStatus.reason !== 'error') {
    showLicenseModal(licenseStatus.message, licenseKey);
  }
}

// The hub can reject a key later (cancelled, payment failed, too many devices).
chrome.storage.onChanged.addListener((changes, area) => {
  const st = area === 'local' && changes.licenseStatus && changes.licenseStatus.newValue;
  if (st && st.ok === false && st.reason !== 'error') showLicenseModal(st.message);
});

let licenseFormWired = false;

function showLicenseModal(message, prefill) {
  const modal = $('emailModal');
  const input = $('userEmail');
  const msg = $('licenseMsg');
  if (message) {
    msg.textContent = message;
    msg.classList.add('license-error');
  }
  if (prefill && !input.value) input.value = prefill;
  modal.classList.add('active');
  input.focus();

  if (licenseFormWired) return;
  licenseFormWired = true;

  $('emailForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const key = input.value.trim().toUpperCase();
    const btn = $('emailSubmit');
    if (!key) return;

    btn.disabled = true;
    btn.textContent = 'Checking...';
    try {
      const qs = new URLSearchParams({ key, device: await getDeviceId() });
      const res = await fetch(`${LICENSE_API}?${qs}`, { cache: 'no-store' });
      const data = await res.json();
      if (data.ok) {
        await chrome.storage.local.set({ licenseKey: key, licenseStatus: data });
        hideLicenseModal();
      } else {
        msg.textContent = data.message || "That key didn't work.";
        msg.classList.add('license-error');
      }
    } catch (err) {
      msg.textContent = "Couldn't reach stakecodedrop.com. Check your connection and try again.";
      msg.classList.add('license-error');
    }
    btn.disabled = false;
    btn.textContent = 'Activate';
  });
}

function hideLicenseModal() {
  $('emailModal').classList.remove('active');
  const msg = $('licenseMsg');
  msg.textContent = 'Paste the key from your welcome email to start claiming.';
  msg.classList.remove('license-error');
}


/* ------------------------------------------------------- license strip --- */

const PLAN_LABELS = { '1m': 'Monthly plan', '3m': '3-month plan', '6m': '6-month plan', '1y': 'Yearly plan' };

function licDate(ts) {
  return new Date(ts * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

function licDaysLeft(ts) {
  const d = Math.ceil((ts * 1000 - Date.now()) / 86400000);
  return d <= 0 ? 'ends today' : d === 1 ? '1 day left' : `${d} days left`;
}

async function renderLicense() {
  const { licenseKey, licenseStatus: st } = await chrome.storage.local.get({ licenseKey: '', licenseStatus: null });
  const bar = $('licenseBar');
  if (!licenseKey || !st) { bar.hidden = true; return; }
  bar.hidden = false;
  bar.href = 'https://stakecodedrop.com/lib/account.php?key=' + encodeURIComponent(licenseKey);

  const valid = st.valid !== false && (st.status === 'trialing' || st.status === 'active');
  let title, when;
  if (!valid) {
    title = st.status === 'past_due' ? 'Payment failed' : 'Subscription inactive';
    when = st.status === 'past_due' ? 'Update your card to keep claiming' : 'Renew to keep claiming';
  } else if (st.status === 'trialing') {
    const end = st.trial_end || st.current_period_end;
    title = 'Free trial' + (end ? ' · ' + licDaysLeft(end) : '');
    when = end ? (st.cancel_at_period_end ? 'Ends ' : 'Paid plan starts ') + licDate(end) : '';
  } else {
    const end = st.current_period_end;
    title = PLAN_LABELS[st.plan] || 'Active';
    when = end ? (st.cancel_at_period_end ? 'Ends ' + licDate(end) + ' · ' + licDaysLeft(end) : 'Renews ' + licDate(end)) : '';
  }
  $('licTitle').textContent = when ? `${title} · ${when}` : title;
  $('licDot').className = 'lic-dot ' + (!valid ? 'off' : st.cancel_at_period_end ? 'warn' : 'on');
}

// Ask the server for the latest status each time the popup opens.
async function refreshLicense() {
  const { licenseKey } = await chrome.storage.local.get({ licenseKey: '' });
  if (!licenseKey) return;
  try {
    const qs = new URLSearchParams({ key: licenseKey, device: await getDeviceId() });
    const res = await fetch(`${LICENSE_API}?${qs}`, { cache: 'no-store' });
    const data = await res.json();
    if (data.reason !== 'error') await chrome.storage.local.set({ licenseStatus: data });
  } catch (e) { /* offline: keep the last known status */ }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.licenseStatus || changes.licenseKey)) renderLicense();
});
